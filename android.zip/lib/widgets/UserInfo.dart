class UserInformation {
  String? username;
  String? customBio;
  String? imgurl;
}