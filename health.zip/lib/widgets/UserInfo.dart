class UserInformation {
  String username;
  String customBio;
  String imgUrl;
}